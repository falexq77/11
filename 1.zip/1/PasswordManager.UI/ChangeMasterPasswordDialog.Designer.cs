namespace PasswordManager;

partial class ChangeMasterPasswordDialog
{
    private System.ComponentModel.IContainer components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        lblOld = new Label();
        txtOld = new TextBox();
        lblNew1 = new Label();
        txtNew1 = new TextBox();
        lblNew2 = new Label();
        txtNew2 = new TextBox();
        btnOk = new Button();
        btnCancel = new Button();
        SuspendLayout();
        // 
        // lblOld
        // 
        lblOld.AutoSize = true;
        lblOld.Location = new Point(12, 15);
        lblOld.Name = "lblOld";
        lblOld.TabIndex = 0;
        lblOld.Text = "Текущий мастер-пароль:";
        // 
        // txtOld
        // 
        txtOld.Location = new Point(12, 40);
        txtOld.Name = "txtOld";
        txtOld.Size = new Size(330, 26);
        txtOld.TabIndex = 1;
        txtOld.UseSystemPasswordChar = true;
        // 
        // lblNew1
        // 
        lblNew1.AutoSize = true;
        lblNew1.Location = new Point(12, 75);
        lblNew1.Name = "lblNew1";
        lblNew1.TabIndex = 2;
        lblNew1.Text = "Новый мастер-пароль (мин. 8 символов):";
        // 
        // txtNew1
        // 
        txtNew1.Location = new Point(12, 100);
        txtNew1.Name = "txtNew1";
        txtNew1.Size = new Size(330, 26);
        txtNew1.TabIndex = 3;
        txtNew1.UseSystemPasswordChar = true;
        // 
        // lblNew2
        // 
        lblNew2.AutoSize = true;
        lblNew2.Location = new Point(12, 135);
        lblNew2.Name = "lblNew2";
        lblNew2.TabIndex = 4;
        lblNew2.Text = "Повторите новый пароль:";
        // 
        // txtNew2
        // 
        txtNew2.Location = new Point(12, 160);
        txtNew2.Name = "txtNew2";
        txtNew2.Size = new Size(330, 26);
        txtNew2.TabIndex = 5;
        txtNew2.UseSystemPasswordChar = true;
        // 
        // btnOk
        // 
        btnOk.DialogResult = DialogResult.None;
        btnOk.Location = new Point(170, 195);
        btnOk.Name = "btnOk";
        btnOk.Size = new Size(80, 30);
        btnOk.TabIndex = 6;
        btnOk.Text = "Сменить";
        btnOk.UseVisualStyleBackColor = true;
        btnOk.Click += BtnOk_Click;
        // 
        // btnCancel
        // 
        btnCancel.DialogResult = DialogResult.Cancel;
        btnCancel.Location = new Point(260, 195);
        btnCancel.Name = "btnCancel";
        btnCancel.Size = new Size(80, 30);
        btnCancel.TabIndex = 7;
        btnCancel.Text = "Отмена";
        btnCancel.UseVisualStyleBackColor = true;
        // 
        // ChangeMasterPasswordDialog
        // 
        AcceptButton = btnOk;
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        CancelButton = btnCancel;
        ClientSize = new Size(360, 235);
        Controls.Add(lblOld);
        Controls.Add(txtOld);
        Controls.Add(lblNew1);
        Controls.Add(txtNew1);
        Controls.Add(lblNew2);
        Controls.Add(txtNew2);
        Controls.Add(btnOk);
        Controls.Add(btnCancel);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "ChangeMasterPasswordDialog";
        StartPosition = FormStartPosition.CenterParent;
        Text = "Смена мастер-пароля";
        ResumeLayout(false);
        PerformLayout();
    }

    #endregion

    private Label lblOld;
    private TextBox txtOld;
    private Label lblNew1;
    private TextBox txtNew1;
    private Label lblNew2;
    private TextBox txtNew2;
    private Button btnOk;
    private Button btnCancel;
}

namespace PasswordManager;

public partial class ChangeMasterPasswordDialog : Form
{
    public ChangeMasterPasswordDialog()
    {
        InitializeComponent();
    }

    private void BtnOk_Click(object? sender, EventArgs e)
    {
        if (txtOld.Text.Length == 0)
        {
            MessageBox.Show(this, "Введите текущий мастер-пароль.", "Проверка",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (txtNew1.Text.Length < 8)
        {
            MessageBox.Show(this, "Новый пароль должен быть не короче 8 символов.", "Проверка",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (txtNew1.Text != txtNew2.Text)
        {
            MessageBox.Show(this, "Новые пароли не совпадают.", "Проверка",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var user = Database.FindUser(Session.Username);
        if (user is null || !PasswordHasher.Verify(txtOld.Text, user.Value.MasterHash))
        {
            MessageBox.Show(this, "Текущий мастер-пароль неверен.", "Проверка",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        byte[] newKeySalt = PasswordHasher.NewKeySalt();
        byte[] newKey = PasswordHasher.DeriveKey(txtNew1.Text, newKeySalt);
        Database.ChangeMaster(Session.UserId, Session.Key, PasswordHasher.Hash(txtNew1.Text), newKeySalt, newKey);
        Session.Start(Session.UserId, Session.Username, newKey);

        MessageBox.Show(this, "Мастер-пароль изменён.", "Готово",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
        DialogResult = DialogResult.OK;
        Close();
    }
}

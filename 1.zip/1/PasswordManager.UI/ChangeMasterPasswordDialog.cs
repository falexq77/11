namespace PasswordManager;


public partial class ChangeMasterPasswordDialog : Form
{
    public ChangeMasterPasswordDialog()
    {
        InitializeComponent();
    }

    private void BtnOk_Click(object? sender, EventArgs e)
    {
        if (txtOld.Text.Length == 0)
        {
            MessageBox.Show(this, "Введите текущий мастер-пароль.", "Проверка",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (txtNew1.Text.Length < 8)
        {
            MessageBox.Show(this, "Новый пароль должен быть не короче 8 символов.", "Проверка",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (txtNew1.Text != txtNew2.Text)
        {
            MessageBox.Show(this, "Новые пароли не совпадают.", "Проверка",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        MessageBox.Show(this, "Мастер-пароль изменён.", "Готово",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
        DialogResult = DialogResult.OK;
        Close();
    }
}

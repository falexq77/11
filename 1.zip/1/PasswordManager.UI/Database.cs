using Microsoft.Data.Sqlite;

namespace PasswordManager;

internal static class Database
{
    private static readonly string ConnectionString = new SqliteConnectionStringBuilder
    {
        DataSource = Path.Combine(AppContext.BaseDirectory, "vault.db"),
        ForeignKeys = true
    }.ToString();

    public static void Init()
    {
        using var c = Open();
        Exec(c, """
            CREATE TABLE IF NOT EXISTS users (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                username    TEXT NOT NULL UNIQUE COLLATE NOCASE,
                master_hash TEXT NOT NULL,
                key_salt    BLOB NOT NULL,
                created_at  TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS entries (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                title    TEXT NOT NULL,
                login    TEXT NOT NULL,
                password TEXT NOT NULL,
                url      TEXT NOT NULL,
                notes    TEXT NOT NULL,
                updated  TEXT NOT NULL
            );
            """);
    }

    private static SqliteConnection Open()
    {
        var c = new SqliteConnection(ConnectionString);
        c.Open();
        return c;
    }

    private static SqliteCommand Cmd(SqliteConnection c, string sql, params (string Name, object Value)[] args)
    {
        var cmd = c.CreateCommand();
        cmd.CommandText = sql;
        foreach (var (name, value) in args) cmd.Parameters.AddWithValue(name, value);
        return cmd;
    }

    private static void Exec(SqliteConnection c, string sql, params (string, object)[] args)
    {
        using var cmd = Cmd(c, sql, args);
        cmd.ExecuteNonQuery();
    }

    public static long? CreateUser(string username, string masterHash, byte[] keySalt)
    {
        using var c = Open();
        using var cmd = Cmd(c,
            "INSERT INTO users (username, master_hash, key_salt, created_at) VALUES ($u, $h, $s, $t) RETURNING id",
            ("$u", username), ("$h", masterHash), ("$s", keySalt), ("$t", DateTime.UtcNow.ToString("o")));
        try
        {
            return (long)cmd.ExecuteScalar()!;
        }
        catch (SqliteException e) when (e.SqliteErrorCode == 19)
        {
            return null;
        }
    }

    public static (long Id, string Username, string MasterHash, byte[] KeySalt)? FindUser(string username)
    {
        using var c = Open();
        using var cmd = Cmd(c, "SELECT id, username, master_hash, key_salt FROM users WHERE username = $u", ("$u", username));
        using var r = cmd.ExecuteReader();
        if (!r.Read()) return null;
        return (r.GetInt64(0), r.GetString(1), r.GetString(2), (byte[])r["key_salt"]);
    }

    public static void ChangeMaster(long userId, byte[] oldKey, string newHash, byte[] newKeySalt, byte[] newKey)
    {
        var entries = GetEntries(userId, oldKey);
        using var c = Open();
        using var tx = c.BeginTransaction();
        Exec(c, "UPDATE users SET master_hash = $h, key_salt = $s WHERE id = $id",
            ("$h", newHash), ("$s", newKeySalt), ("$id", userId));
        foreach (var en in entries)
            Exec(c, "UPDATE entries SET password = $p, notes = $n WHERE id = $id",
                ("$p", PasswordHasher.Encrypt(newKey, en.Password)),
                ("$n", PasswordHasher.Encrypt(newKey, en.Notes)),
                ("$id", en.Id));
        tx.Commit();
    }

    public static List<VaultEntry> GetEntries(long userId, byte[] key)
    {
        var list = new List<VaultEntry>();
        using var c = Open();
        using var cmd = Cmd(c,
            "SELECT id, title, login, password, url, notes, updated FROM entries WHERE user_id = $uid ORDER BY title COLLATE NOCASE",
            ("$uid", userId));
        using var r = cmd.ExecuteReader();
        while (r.Read())
            list.Add(new VaultEntry
            {
                Id = r.GetInt64(0),
                Title = r.GetString(1),
                Login = r.GetString(2),
                Password = PasswordHasher.Decrypt(key, r.GetString(3)),
                Url = r.GetString(4),
                Notes = PasswordHasher.Decrypt(key, r.GetString(5)),
                Updated = DateTime.Parse(r.GetString(6), null, System.Globalization.DateTimeStyles.RoundtripKind).ToLocalTime()
            });
        return list;
    }

    public static void SaveEntry(long userId, byte[] key, VaultEntry en)
    {
        using var c = Open();
        var args = new (string, object)[]
        {
            ("$uid", userId), ("$title", en.Title), ("$login", en.Login),
            ("$pass", PasswordHasher.Encrypt(key, en.Password)), ("$url", en.Url),
            ("$notes", PasswordHasher.Encrypt(key, en.Notes)), ("$upd", en.Updated.ToUniversalTime().ToString("o"))
        };
        if (en.Id == 0)
        {
            using var cmd = Cmd(c, """
                INSERT INTO entries (user_id, title, login, password, url, notes, updated)
                VALUES ($uid, $title, $login, $pass, $url, $notes, $upd) RETURNING id
                """, args);
            en.Id = (long)cmd.ExecuteScalar()!;
        }
        else
        {
            Exec(c, """
                UPDATE entries SET title = $title, login = $login, password = $pass, url = $url, notes = $notes, updated = $upd
                WHERE id = $id AND user_id = $uid
                """, [.. args, ("$id", en.Id)]);
        }
    }

    public static void DeleteEntry(long userId, long entryId)
    {
        using var c = Open();
        Exec(c, "DELETE FROM entries WHERE id = $id AND user_id = $uid", ("$id", entryId), ("$uid", userId));
    }
}

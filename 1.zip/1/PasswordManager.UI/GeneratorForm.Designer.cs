namespace PasswordManager;

partial class GeneratorForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            components?.Dispose();
        }
        base.Dispose(disposing);
    }

    private Label lblLen;
    private NumericUpDown _numLength;
    private CheckedListBox _options;
    private Button btnGen;
    private Label lblRes;
    private TextBox _result;
    private Label _lblEntropy;
    private Button btnCopy;
    private Button btnUse;

    #region Windows Form Designer generated code

    private void InitializeComponent()
    {
        lblLen = new Label();
        _numLength = new NumericUpDown();
        _options = new CheckedListBox();
        btnGen = new Button();
        lblRes = new Label();
        _result = new TextBox();
        _lblEntropy = new Label();
        btnCopy = new Button();
        btnUse = new Button();
        ((System.ComponentModel.ISupportInitialize)_numLength).BeginInit();
        SuspendLayout();

        AutoScaleDimensions = new SizeF(7f, 15f);
        AutoScaleMode = AutoScaleMode.Font;
        Text = "Генератор паролей";
        Name = "GeneratorForm";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;
        ClientSize = new Size(380, 260);

        lblLen.Text = "Длина:";
        lblLen.AutoSize = true;
        lblLen.Name = "lblLen";
        lblLen.Location = new Point(14, 17);

        _numLength.Location = new Point(80, 15);
        _numLength.Name = "_numLength";
        _numLength.Size = new Size(70, 23);
        _numLength.TabIndex = 1;
        _numLength.Minimum = 6;
        _numLength.Maximum = 64;
        _numLength.Value = 16;

        _options.Location = new Point(14, 48);
        _options.Name = "_options";
        _options.Size = new Size(180, 100);
        _options.TabIndex = 2;
        _options.CheckOnClick = true;
        _options.Items.AddRange(new object[] { "Заглавные (A–Z)", "Строчные (a–z)", "Цифры (0–9)", "Символы (!@#$…)" });

        btnGen.Text = "⟳";
        btnGen.Name = "btnGen";
        btnGen.Location = new Point(204, 48);
        btnGen.Size = new Size(36, 30);
        btnGen.TabIndex = 3;
        btnGen.Font = new Font(this.Font.FontFamily, 12f);
        btnGen.Click += BtnGen_Click;

        lblRes.Text = "Результат:";
        lblRes.AutoSize = true;
        lblRes.Name = "lblRes";
        lblRes.Location = new Point(14, 158);

        _result.Location = new Point(80, 155);
        _result.Name = "_result";
        _result.Size = new Size(285, 23);
        _result.TabIndex = 5;
        _result.ReadOnly = true;
        _result.Font = new Font("Consolas", 11f);

        _lblEntropy.Location = new Point(80, 185);
        _lblEntropy.Name = "_lblEntropy";
        _lblEntropy.AutoSize = true;
        _lblEntropy.ForeColor = Color.Gray;

        btnCopy.Text = "Копировать";
        btnCopy.Name = "btnCopy";
        btnCopy.Location = new Point(14, 215);
        btnCopy.Size = new Size(110, 30);
        btnCopy.TabIndex = 6;
        btnCopy.Click += BtnCopy_Click;

        btnUse.Text = "Закрыть";
        btnUse.Name = "btnUse";
        btnUse.DialogResult = DialogResult.OK;
        btnUse.Location = new Point(255, 215);
        btnUse.Size = new Size(110, 30);
        btnUse.TabIndex = 7;

        Controls.AddRange(new Control[] { lblLen, _numLength, _options, btnGen, lblRes, _result, _lblEntropy, btnCopy, btnUse });
        AcceptButton = btnUse;

        ((System.ComponentModel.ISupportInitialize)_numLength).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    #endregion

}

namespace PasswordManager;
public partial class GeneratorForm : Form
{
    private readonly TextBox? _fillTarget;

    public GeneratorForm(TextBox? fillTarget = null)
    {
        _fillTarget = fillTarget;
        InitializeComponent();

        _numLength.ValueChanged += (_, _) => GenerateNow();

        if (_fillTarget is not null) btnUse.Text = "Использовать";

        for (int i = 0; i < _options.Items.Count; i++) _options.SetItemChecked(i, true);
        GenerateNow();

        _options.ItemCheck += (_, _) => BeginInvoke(new Action(GenerateNow));
    }
    private void BtnGen_Click(object? sender, EventArgs e) => GenerateNow();

    private void BtnCopy_Click(object? sender, EventArgs e)
    {
        if (_result.Text.Length > 0) Clipboard.SetText(_result.Text);
    }
    private void GenerateNow()
    {
        if (_options.CheckedItems.Count == 0)
        {
            _result.Text = "";
            _lblEntropy.Text = "Выберите хотя бы один набор символов.";
            _lblEntropy.ForeColor = Color.Firebrick;
            return;
        }

        _result.Text = PasswordGenerator.Generate((int)_numLength.Value,
            _options.GetItemChecked(0), _options.GetItemChecked(1),
            _options.GetItemChecked(2), _options.GetItemChecked(3));
        _lblEntropy.Text = $"Надёжность: {PasswordGenerator.StrengthText(_result.Text)}";
        _lblEntropy.ForeColor = PasswordGenerator.StrengthColor(_result.Text);
    }
    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        if (DialogResult == DialogResult.OK && _fillTarget is not null && _result.Text.Length > 0)
            _fillTarget.Text = _result.Text;
        base.OnFormClosed(e);
    }
}

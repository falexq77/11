namespace PasswordManager;

partial class LoginForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            components?.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    private void InitializeComponent()
    {
        _tabs = new TabControl();
        tabLogin = new TabPage();
        _lblLoginUser = new Label();
        _loginUser = new TextBox();
        _lblLoginPass = new Label();
        _loginPass = new TextBox();
        _showLoginPass = new CheckBox();
        _btnLogin = new Button();
        tabRegister = new TabPage();
        _lblRegUser = new Label();
        _regUser = new TextBox();
        _lblRegPass1 = new Label();
        _regPass1 = new TextBox();
        _btnGenMaster = new Button();
        _lblRegEntropy = new Label();
        _lblRegPass2 = new Label();
        _regPass2 = new TextBox();
        _lblSample = new Label();
        _regGenerated = new TextBox();
        _btnGenSample = new Button();
        _btnRegister = new Button();
        _status = new StatusStrip();
        _statusLabel = new ToolStripStatusLabel();
        _tabs.SuspendLayout();
        tabLogin.SuspendLayout();
        tabRegister.SuspendLayout();
        _status.SuspendLayout();
        SuspendLayout();
        // 
        // _tabs
        // 
        _tabs.Controls.Add(tabLogin);
        _tabs.Controls.Add(tabRegister);
        _tabs.Location = new Point(12, 12);
        _tabs.Name = "_tabs";
        _tabs.SelectedIndex = 0;
        _tabs.Size = new Size(396, 343);
        _tabs.TabIndex = 0;
        // 
        // tabLogin
        // 
        tabLogin.Controls.Add(_lblLoginUser);
        tabLogin.Controls.Add(_loginUser);
        tabLogin.Controls.Add(_lblLoginPass);
        tabLogin.Controls.Add(_loginPass);
        tabLogin.Controls.Add(_showLoginPass);
        tabLogin.Controls.Add(_btnLogin);
        tabLogin.Location = new Point(4, 24);
        tabLogin.Name = "tabLogin";
        tabLogin.Padding = new Padding(3);
        tabLogin.Size = new Size(388, 315);
        tabLogin.TabIndex = 0;
        tabLogin.Text = "Вход";
        tabLogin.UseVisualStyleBackColor = true;
        // 
        // _lblLoginUser
        // 
        _lblLoginUser.AutoSize = true;
        _lblLoginUser.Location = new Point(15, 20);
        _lblLoginUser.Name = "_lblLoginUser";
        _lblLoginUser.Size = new Size(112, 15);
        _lblLoginUser.TabIndex = 0;
        _lblLoginUser.Text = "Имя пользователя:";
        // 
        // _loginUser
        // 
        _loginUser.Location = new Point(15, 45);
        _loginUser.Name = "_loginUser";
        _loginUser.Size = new Size(350, 23);
        _loginUser.TabIndex = 1;
        // 
        // _lblLoginPass
        // 
        _lblLoginPass.AutoSize = true;
        _lblLoginPass.Location = new Point(15, 80);
        _lblLoginPass.Name = "_lblLoginPass";
        _lblLoginPass.Size = new Size(96, 15);
        _lblLoginPass.TabIndex = 2;
        _lblLoginPass.Text = "Мастер-пароль:";
        // 
        // _loginPass
        // 
        _loginPass.Location = new Point(15, 105);
        _loginPass.Name = "_loginPass";
        _loginPass.Size = new Size(270, 23);
        _loginPass.TabIndex = 3;
        _loginPass.UseSystemPasswordChar = true;
        // 
        // _showLoginPass
        // 
        _showLoginPass.AutoSize = true;
        _showLoginPass.Location = new Point(295, 107);
        _showLoginPass.Name = "_showLoginPass";
        _showLoginPass.Size = new Size(76, 19);
        _showLoginPass.TabIndex = 4;
        _showLoginPass.Text = "Показать";
        _showLoginPass.CheckedChanged += ShowLoginPass_CheckedChanged;
        // 
        // _btnLogin
        // 
        _btnLogin.Location = new Point(15, 150);
        _btnLogin.Name = "_btnLogin";
        _btnLogin.Size = new Size(350, 38);
        _btnLogin.TabIndex = 5;
        _btnLogin.Text = "Войти";
        _btnLogin.Click += BtnLogin_Click;
        // 
        // tabRegister
        // 
        tabRegister.Controls.Add(_lblRegUser);
        tabRegister.Controls.Add(_regUser);
        tabRegister.Controls.Add(_lblRegPass1);
        tabRegister.Controls.Add(_regPass1);
        tabRegister.Controls.Add(_btnGenMaster);
        tabRegister.Controls.Add(_lblRegEntropy);
        tabRegister.Controls.Add(_lblRegPass2);
        tabRegister.Controls.Add(_regPass2);
        tabRegister.Controls.Add(_lblSample);
        tabRegister.Controls.Add(_regGenerated);
        tabRegister.Controls.Add(_btnGenSample);
        tabRegister.Controls.Add(_btnRegister);
        tabRegister.Location = new Point(4, 24);
        tabRegister.Name = "tabRegister";
        tabRegister.Padding = new Padding(3);
        tabRegister.Size = new Size(388, 315);
        tabRegister.TabIndex = 1;
        tabRegister.Text = "Регистрация";
        tabRegister.UseVisualStyleBackColor = true;
        // 
        // _lblRegUser
        // 
        _lblRegUser.AutoSize = true;
        _lblRegUser.Location = new Point(15, 15);
        _lblRegUser.Name = "_lblRegUser";
        _lblRegUser.Size = new Size(181, 15);
        _lblRegUser.TabIndex = 0;
        _lblRegUser.Text = "Придумайте имя пользователя:";
        // 
        // _regUser
        // 
        _regUser.Location = new Point(15, 40);
        _regUser.Name = "_regUser";
        _regUser.Size = new Size(350, 23);
        _regUser.TabIndex = 1;
        // 
        // _lblRegPass1
        // 
        _lblRegPass1.AutoSize = true;
        _lblRegPass1.Location = new Point(15, 75);
        _lblRegPass1.Name = "_lblRegPass1";
        _lblRegPass1.Size = new Size(228, 15);
        _lblRegPass1.TabIndex = 2;
        _lblRegPass1.Text = "Мастер-пароль (минимум 8 символов):";
        // 
        // _regPass1
        // 
        _regPass1.Location = new Point(15, 100);
        _regPass1.Name = "_regPass1";
        _regPass1.Size = new Size(210, 23);
        _regPass1.TabIndex = 3;
        _regPass1.UseSystemPasswordChar = true;
        // 
        // _btnGenMaster
        // 
        _btnGenMaster.Location = new Point(235, 99);
        _btnGenMaster.Name = "_btnGenMaster";
        _btnGenMaster.Size = new Size(130, 23);
        _btnGenMaster.TabIndex = 4;
        _btnGenMaster.Text = "Сгенерировать";
        _btnGenMaster.Click += BtnGenMaster_Click;
        // 
        // _lblRegEntropy
        // 
        _lblRegEntropy.Font = new Font("Segoe UI", 8.5F);
        _lblRegEntropy.ForeColor = Color.Gray;
        _lblRegEntropy.Location = new Point(15, 128);
        _lblRegEntropy.Name = "_lblRegEntropy";
        _lblRegEntropy.Size = new Size(350, 18);
        _lblRegEntropy.TabIndex = 5;
        _lblRegEntropy.Text = "Надёжность: —";
        // 
        // _lblRegPass2
        // 
        _lblRegPass2.AutoSize = true;
        _lblRegPass2.Location = new Point(15, 155);
        _lblRegPass2.Name = "_lblRegPass2";
        _lblRegPass2.Size = new Size(156, 15);
        _lblRegPass2.TabIndex = 6;
        _lblRegPass2.Text = "Повторите мастер-пароль:";
        // 
        // _regPass2
        // 
        _regPass2.Location = new Point(15, 180);
        _regPass2.Name = "_regPass2";
        _regPass2.Size = new Size(350, 23);
        _regPass2.TabIndex = 7;
        _regPass2.UseSystemPasswordChar = true;
        // 
        // _lblSample
        // 
        _lblSample.AutoSize = true;
        _lblSample.Location = new Point(15, 215);
        _lblSample.Name = "_lblSample";
        _lblSample.Size = new Size(260, 15);
        _lblSample.TabIndex = 8;
        _lblSample.Text = "(необязательно) Пароль для примера записи:";
        // 
        // _regGenerated
        // 
        _regGenerated.Location = new Point(15, 240);
        _regGenerated.Name = "_regGenerated";
        _regGenerated.ReadOnly = true;
        _regGenerated.Size = new Size(270, 23);
        _regGenerated.TabIndex = 9;
        // 
        // _btnGenSample
        // 
        _btnGenSample.Location = new Point(295, 239);
        _btnGenSample.Name = "_btnGenSample";
        _btnGenSample.Size = new Size(70, 23);
        _btnGenSample.TabIndex = 10;
        _btnGenSample.Text = "Генератор";
        _btnGenSample.Click += BtnGenSample_Click;
        // 
        // _btnRegister
        // 
        _btnRegister.Location = new Point(15, 272);
        _btnRegister.Name = "_btnRegister";
        _btnRegister.Size = new Size(350, 34);
        _btnRegister.TabIndex = 11;
        _btnRegister.Text = "Создать учётную запись";
        _btnRegister.Click += BtnRegister_Click;
        // 
        // _status
        // 
        _status.Items.AddRange(new ToolStripItem[] { _statusLabel });
        _status.Location = new Point(0, 358);
        _status.Name = "_status";
        _status.Size = new Size(420, 22);
        _status.TabIndex = 1;
        // 
        // _statusLabel
        // 
        _statusLabel.Name = "_statusLabel";
        _statusLabel.Size = new Size(0, 17);
        // 
        // LoginForm
        // 
        AcceptButton = _btnLogin;
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(420, 380);
        Controls.Add(_tabs);
        Controls.Add(_status);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "LoginForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Менеджер паролей — Авторизация";
        _tabs.ResumeLayout(false);
        tabLogin.ResumeLayout(false);
        tabLogin.PerformLayout();
        tabRegister.ResumeLayout(false);
        tabRegister.PerformLayout();
        _status.ResumeLayout(false);
        _status.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }

    #endregion

    private TabControl _tabs;
    private TabPage tabLogin;
    private TabPage tabRegister;
    private Label _lblLoginUser;
    private TextBox _loginUser;
    private Label _lblLoginPass;
    private TextBox _loginPass;
    private CheckBox _showLoginPass;
    private Button _btnLogin;
    private Label _lblRegUser;
    private TextBox _regUser;
    private Label _lblRegPass1;
    private TextBox _regPass1;
    private Button _btnGenMaster;
    private Label _lblRegEntropy;
    private Label _lblRegPass2;
    private TextBox _regPass2;
    private Label _lblSample;
    private TextBox _regGenerated;
    private Button _btnGenSample;
    private Button _btnRegister;
    private StatusStrip _status;
    private ToolStripStatusLabel _statusLabel;
}

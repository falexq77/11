namespace PasswordManager;
public partial class LoginForm : Form
{
    public LoginForm()
    {
        InitializeComponent();
    }

    private void ShowLoginPass_CheckedChanged(object? sender, EventArgs e) =>
        _loginPass.UseSystemPasswordChar = !_showLoginPass.Checked;

    private void BtnGenMaster_Click(object? sender, EventArgs e)
    {
        _regPass1.Text = UiStub.PlaceholderPassword(20);
        _regPass2.Text = _regPass1.Text;
    }

    private void BtnGenSample_Click(object? sender, EventArgs e) =>
        _regGenerated.Text = UiStub.PlaceholderPassword(16);

    private void BtnLogin_Click(object? sender, EventArgs e)
    {
        if (_loginUser.Text.Trim().Length == 0 || _loginPass.Text.Length == 0)
        {
            SetStatus("Заполните имя пользователя и мастер-пароль.", Color.Firebrick);
            return;
        }
        SetStatus("Вход выполнен.");
        DialogResult = DialogResult.OK;
        Close();
    }

    private void BtnRegister_Click(object? sender, EventArgs e)
    {
        if (_regUser.Text.Trim().Length == 0 || _regPass1.Text.Length == 0)
        {
            SetStatus("Заполните имя пользователя и мастер-пароль.", Color.Firebrick);
            return;
        }
        if (_regPass1.Text != _regPass2.Text)
        {
            SetStatus("Пароли не совпадают.", Color.Firebrick);
            return;
        }
        SetStatus("Учётная запись создана.");
        DialogResult = DialogResult.OK;
        Close();
    }

    private void SetStatus(string text, Color? color = null)
    {
        _statusLabel.Text = text;
        _statusLabel.ForeColor = color ?? Color.Empty;
    }
}

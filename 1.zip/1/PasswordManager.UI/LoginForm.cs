namespace PasswordManager;
public partial class LoginForm : Form
{
    public LoginForm()
    {
        InitializeComponent();
        _regPass1.TextChanged += (_, _) => UpdateRegStrength();
    }

    private void ShowLoginPass_CheckedChanged(object? sender, EventArgs e) =>
        _loginPass.UseSystemPasswordChar = !_showLoginPass.Checked;

    private void BtnGenMaster_Click(object? sender, EventArgs e)
    {
        _regPass1.Text = PasswordGenerator.Generate(20);
        _regPass2.Text = _regPass1.Text;
    }

    private void BtnGenSample_Click(object? sender, EventArgs e) =>
        _regGenerated.Text = PasswordGenerator.Generate(16);

    private void UpdateRegStrength()
    {
        if (_regPass1.Text.Length == 0)
        {
            _lblRegEntropy.Text = "Надёжность: —";
            _lblRegEntropy.ForeColor = Color.Empty;
            return;
        }
        _lblRegEntropy.Text = $"Надёжность: {PasswordGenerator.StrengthText(_regPass1.Text)}";
        _lblRegEntropy.ForeColor = PasswordGenerator.StrengthColor(_regPass1.Text);
    }

    private void BtnLogin_Click(object? sender, EventArgs e)
    {
        string username = _loginUser.Text.Trim();
        if (username.Length == 0 || _loginPass.Text.Length == 0)
        {
            SetStatus("Заполните имя пользователя и мастер-пароль.", Color.Firebrick);
            return;
        }

        var user = Database.FindUser(username);
        if (user is null || !PasswordHasher.Verify(_loginPass.Text, user.Value.MasterHash))
        {
            SetStatus("Неверное имя пользователя или мастер-пароль.", Color.Firebrick);
            _loginPass.Clear();
            return;
        }

        Session.Start(user.Value.Id, user.Value.Username, PasswordHasher.DeriveKey(_loginPass.Text, user.Value.KeySalt,
            PasswordHasher.IterationsOf(user.Value.MasterHash)));
        SetStatus("Вход выполнен.");
        DialogResult = DialogResult.OK;
        Close();
    }

    private void BtnRegister_Click(object? sender, EventArgs e)
    {
        string username = _regUser.Text.Trim();
        if (username.Length == 0 || _regPass1.Text.Length == 0)
        {
            SetStatus("Заполните имя пользователя и мастер-пароль.", Color.Firebrick);
            return;
        }
        if (_regPass1.Text.Length < 8)
        {
            SetStatus("Мастер-пароль должен быть не короче 8 символов.", Color.Firebrick);
            return;
        }
        if (_regPass1.Text != _regPass2.Text)
        {
            SetStatus("Пароли не совпадают.", Color.Firebrick);
            return;
        }

        byte[] keySalt = PasswordHasher.NewKeySalt();
        long? userId = Database.CreateUser(username, PasswordHasher.Hash(_regPass1.Text), keySalt);
        if (userId is null)
        {
            SetStatus("Пользователь с таким именем уже существует.", Color.Firebrick);
            return;
        }

        Session.Start(userId.Value, username, PasswordHasher.DeriveKey(_regPass1.Text, keySalt));

        if (_regGenerated.Text.Length > 0)
            Database.SaveEntry(Session.UserId, Session.Key,
                new VaultEntry { Title = "Пример записи", Password = _regGenerated.Text });

        SetStatus("Учётная запись создана.");
        DialogResult = DialogResult.OK;
        Close();
    }

    private void SetStatus(string text, Color? color = null)
    {
        _statusLabel.Text = text;
        _statusLabel.ForeColor = color ?? Color.Empty;
    }
}

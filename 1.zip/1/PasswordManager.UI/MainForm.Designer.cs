namespace PasswordManager;

partial class MainForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            components?.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    private void InitializeComponent()
    {
        colTitle = new ColumnHeader();
        colLogin = new ColumnHeader();
        colUrl = new ColumnHeader();
        colUpdated = new ColumnHeader();
        menu = new MenuStrip();
        miFile = new ToolStripMenuItem();
        miLock = new ToolStripMenuItem();
        miChangeMaster = new ToolStripMenuItem();
        toolStripSeparator1 = new ToolStripSeparator();
        miExit = new ToolStripMenuItem();
        miTools = new ToolStripMenuItem();
        miAudit = new ToolStripMenuItem();
        miGenWindow = new ToolStripMenuItem();
        left = new Panel();
        _list = new ListView();
        searchPanel = new Panel();
        lblSearch = new Label();
        _search = new TextBox();
        right = new GroupBox();
        capTitle = new Label();
        _txtTitle = new TextBox();
        capLogin = new Label();
        _txtLogin = new TextBox();
        capPassword = new Label();
        _txtPassword = new TextBox();
        _showPass = new CheckBox();
        btnGenerate = new Button();
        btnCopy = new Button();
        _lblEntropy = new Label();
        capUrl = new Label();
        _txtUrl = new TextBox();
        capNotes = new Label();
        _txtNotes = new TextBox();
        _btnSave = new Button();
        _btnNew = new Button();
        btnDelete = new Button();
        _status = new StatusStrip();
        _statusLabel = new ToolStripStatusLabel();
        menu.SuspendLayout();
        left.SuspendLayout();
        searchPanel.SuspendLayout();
        right.SuspendLayout();
        _status.SuspendLayout();
        SuspendLayout();
        // 
        // menu
        // 
        menu.Items.AddRange(new ToolStripItem[] { miFile, miTools });
        menu.Location = new Point(0, 0);
        menu.Name = "menu";
        menu.Size = new Size(900, 24);
        menu.TabIndex = 2;
        // 
        // miFile
        // 
        miFile.DropDownItems.AddRange(new ToolStripItem[] { miLock, miChangeMaster, toolStripSeparator1, miExit });
        miFile.Name = "miFile";
        miFile.Size = new Size(48, 20);
        miFile.Text = "&Файл";
        // 
        // miLock
        // 
        miLock.Name = "miLock";
        miLock.Size = new Size(218, 22);
        miLock.Text = "&Заблокировать";
        miLock.Click += MiLock_Click;
        // 
        // miChangeMaster
        // 
        miChangeMaster.Name = "miChangeMaster";
        miChangeMaster.Size = new Size(218, 22);
        miChangeMaster.Text = "Сменить &мастер-пароль...";
        miChangeMaster.Click += MiChangeMaster_Click;
        // 
        // toolStripSeparator1
        // 
        toolStripSeparator1.Name = "toolStripSeparator1";
        toolStripSeparator1.Size = new Size(215, 6);
        // 
        // miExit
        // 
        miExit.Name = "miExit";
        miExit.Size = new Size(218, 22);
        miExit.Text = "Вы&ход";
        miExit.Click += MiExit_Click;
        // 
        // miTools
        // 
        miTools.DropDownItems.AddRange(new ToolStripItem[] { miAudit, miGenWindow });
        miTools.Name = "miTools";
        miTools.Size = new Size(95, 20);
        miTools.Text = "&Инструменты";
        // 
        // miAudit
        // 
        miAudit.Name = "miAudit";
        miAudit.Size = new Size(243, 22);
        miAudit.Text = "&Аудит безопасности";
        miAudit.Click += MiAudit_Click;
        // 
        // miGenWindow
        // 
        miGenWindow.Name = "miGenWindow";
        miGenWindow.Size = new Size(243, 22);
        miGenWindow.Text = "&Генератор паролей (отдельно)";
        miGenWindow.Click += MiGenWindow_Click;
        // 
        // left
        // 
        left.Controls.Add(_list);
        left.Controls.Add(searchPanel);
        left.Dock = DockStyle.Fill;
        left.Location = new Point(0, 24);
        left.Name = "left";
        left.Size = new Size(570, 514);
        left.TabIndex = 0;
        // 
        // colTitle / colLogin / colUrl / colUpdated
        // 
        colTitle.Text = "Название";
        colTitle.Width = 160;
        colLogin.Text = "Логин";
        colLogin.Width = 140;
        colUrl.Text = "URL";
        colUrl.Width = 140;
        colUpdated.Text = "Изменено";
        colUpdated.Width = 110;
        // 
        // _list
        // 
        _list.Columns.AddRange(new ColumnHeader[] { colTitle, colLogin, colUrl, colUpdated });
        _list.Dock = DockStyle.Fill;
        _list.FullRowSelect = true;
        _list.Location = new Point(0, 34);
        _list.MultiSelect = false;
        _list.Name = "_list";
        _list.Size = new Size(570, 480);
        _list.TabIndex = 1;
        _list.UseCompatibleStateImageBehavior = false;
        _list.View = View.Details;
        _list.SelectedIndexChanged += List_SelectedIndexChanged;
        // 
        // searchPanel
        // 
        searchPanel.Controls.Add(lblSearch);
        searchPanel.Controls.Add(_search);
        searchPanel.Dock = DockStyle.Top;
        searchPanel.Location = new Point(0, 0);
        searchPanel.Name = "searchPanel";
        searchPanel.Size = new Size(570, 34);
        searchPanel.TabIndex = 0;
        // 
        // lblSearch
        // 
        lblSearch.AutoSize = true;
        lblSearch.Location = new Point(6, 9);
        lblSearch.Name = "lblSearch";
        lblSearch.Size = new Size(45, 15);
        lblSearch.TabIndex = 0;
        lblSearch.Text = "Поиск:";
        // 
        // _search
        // 
        _search.Location = new Point(58, 6);
        _search.Name = "_search";
        _search.PlaceholderText = "название, логин или URL…";
        _search.Size = new Size(260, 23);
        _search.TabIndex = 1;
        _search.TextChanged += Search_TextChanged;
        // 
        // right
        // 
        right.Controls.Add(capTitle);
        right.Controls.Add(_txtTitle);
        right.Controls.Add(capLogin);
        right.Controls.Add(_txtLogin);
        right.Controls.Add(capPassword);
        right.Controls.Add(_txtPassword);
        right.Controls.Add(_showPass);
        right.Controls.Add(btnGenerate);
        right.Controls.Add(btnCopy);
        right.Controls.Add(_lblEntropy);
        right.Controls.Add(capUrl);
        right.Controls.Add(_txtUrl);
        right.Controls.Add(capNotes);
        right.Controls.Add(_txtNotes);
        right.Controls.Add(_btnSave);
        right.Controls.Add(_btnNew);
        right.Controls.Add(btnDelete);
        right.Dock = DockStyle.Right;
        right.Location = new Point(570, 24);
        right.Name = "right";
        right.Padding = new Padding(10);
        right.Size = new Size(330, 514);
        right.TabIndex = 1;
        right.TabStop = false;
        right.Text = "Запись";
        // 
        // capTitle
        // 
        capTitle.AutoSize = true;
        capTitle.Location = new Point(10, 28);
        capTitle.Name = "capTitle";
        capTitle.Size = new Size(67, 15);
        capTitle.TabIndex = 0;
        capTitle.Text = "Название *";
        // 
        // _txtTitle
        // 
        _txtTitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _txtTitle.Location = new Point(10, 46);
        _txtTitle.Name = "_txtTitle";
        _txtTitle.Size = new Size(300, 23);
        _txtTitle.TabIndex = 1;
        // 
        // capLogin
        // 
        capLogin.AutoSize = true;
        capLogin.Location = new Point(10, 76);
        capLogin.Name = "capLogin";
        capLogin.Size = new Size(41, 15);
        capLogin.TabIndex = 2;
        capLogin.Text = "Логин";
        // 
        // _txtLogin
        // 
        _txtLogin.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _txtLogin.Location = new Point(10, 94);
        _txtLogin.Name = "_txtLogin";
        _txtLogin.Size = new Size(300, 23);
        _txtLogin.TabIndex = 3;
        // 
        // capPassword
        // 
        capPassword.AutoSize = true;
        capPassword.Location = new Point(10, 124);
        capPassword.Name = "capPassword";
        capPassword.Size = new Size(49, 15);
        capPassword.TabIndex = 4;
        capPassword.Text = "Пароль";
        // 
        // _txtPassword
        // 
        _txtPassword.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _txtPassword.Location = new Point(10, 142);
        _txtPassword.Name = "_txtPassword";
        _txtPassword.Size = new Size(300, 23);
        _txtPassword.TabIndex = 5;
        _txtPassword.UseSystemPasswordChar = true;
        // 
        // _showPass
        // 
        _showPass.AutoSize = true;
        _showPass.Location = new Point(10, 172);
        _showPass.Name = "_showPass";
        _showPass.Size = new Size(76, 19);
        _showPass.TabIndex = 6;
        _showPass.Text = "Показать";
        _showPass.CheckedChanged += ShowPass_CheckedChanged;
        // 
        // btnGenerate
        // 
        btnGenerate.Location = new Point(90, 168);
        btnGenerate.Name = "btnGenerate";
        btnGenerate.Size = new Size(120, 25);
        btnGenerate.TabIndex = 7;
        btnGenerate.Text = "Сгенерировать…";
        btnGenerate.Click += BtnGenerate_Click;
        // 
        // btnCopy
        // 
        btnCopy.Location = new Point(215, 168);
        btnCopy.Name = "btnCopy";
        btnCopy.Size = new Size(95, 25);
        btnCopy.TabIndex = 8;
        btnCopy.Text = "Копировать";
        btnCopy.Click += BtnCopy_Click;
        // 
        // _lblEntropy
        // 
        _lblEntropy.ForeColor = Color.Gray;
        _lblEntropy.Location = new Point(10, 202);
        _lblEntropy.Name = "_lblEntropy";
        _lblEntropy.Size = new Size(300, 18);
        _lblEntropy.TabIndex = 9;
        _lblEntropy.Text = "Надёжность: —";
        // 
        // capUrl
        // 
        capUrl.AutoSize = true;
        capUrl.Location = new Point(10, 226);
        capUrl.Name = "capUrl";
        capUrl.Size = new Size(28, 15);
        capUrl.TabIndex = 10;
        capUrl.Text = "URL";
        // 
        // _txtUrl
        // 
        _txtUrl.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _txtUrl.Location = new Point(10, 244);
        _txtUrl.Name = "_txtUrl";
        _txtUrl.Size = new Size(300, 23);
        _txtUrl.TabIndex = 11;
        // 
        // capNotes
        // 
        capNotes.AutoSize = true;
        capNotes.Location = new Point(10, 274);
        capNotes.Name = "capNotes";
        capNotes.Size = new Size(53, 15);
        capNotes.TabIndex = 12;
        capNotes.Text = "Заметки";
        // 
        // _txtNotes
        // 
        _txtNotes.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _txtNotes.Location = new Point(10, 292);
        _txtNotes.Multiline = true;
        _txtNotes.Name = "_txtNotes";
        _txtNotes.ScrollBars = ScrollBars.Vertical;
        _txtNotes.Size = new Size(300, 80);
        _txtNotes.TabIndex = 13;
        // 
        // _btnSave
        // 
        _btnSave.Location = new Point(10, 380);
        _btnSave.Name = "_btnSave";
        _btnSave.Size = new Size(145, 34);
        _btnSave.TabIndex = 14;
        _btnSave.Text = "Сохранить";
        _btnSave.Click += BtnSave_Click;
        // 
        // _btnNew
        // 
        _btnNew.Location = new Point(165, 380);
        _btnNew.Name = "_btnNew";
        _btnNew.Size = new Size(145, 34);
        _btnNew.TabIndex = 15;
        _btnNew.Text = "Новая запись";
        _btnNew.Click += BtnNew_Click;
        // 
        // btnDelete
        // 
        btnDelete.ForeColor = Color.Firebrick;
        btnDelete.Location = new Point(10, 422);
        btnDelete.Name = "btnDelete";
        btnDelete.Size = new Size(300, 30);
        btnDelete.TabIndex = 16;
        btnDelete.Text = "Удалить выбранную";
        btnDelete.Click += BtnDelete_Click;
        // 
        // _status
        // 
        _status.Items.AddRange(new ToolStripItem[] { _statusLabel });
        _status.Location = new Point(0, 538);
        _status.Name = "_status";
        _status.Size = new Size(900, 22);
        _status.TabIndex = 3;
        // 
        // _statusLabel
        // 
        _statusLabel.Name = "_statusLabel";
        _statusLabel.Size = new Size(45, 17);
        _statusLabel.Text = "Готово";
        // 
        // MainForm
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(900, 560);
        Controls.Add(left);
        Controls.Add(right);
        Controls.Add(menu);
        Controls.Add(_status);
        MainMenuStrip = menu;
        MinimumSize = new Size(760, 480);
        Name = "MainForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Менеджер паролей";
        menu.ResumeLayout(false);
        menu.PerformLayout();
        left.ResumeLayout(false);
        searchPanel.ResumeLayout(false);
        searchPanel.PerformLayout();
        right.ResumeLayout(false);
        right.PerformLayout();
        _status.ResumeLayout(false);
        _status.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }

    #endregion

    private ColumnHeader colTitle;
    private ColumnHeader colLogin;
    private ColumnHeader colUrl;
    private ColumnHeader colUpdated;
    private MenuStrip menu;
    private ToolStripMenuItem miFile;
    private ToolStripMenuItem miLock;
    private ToolStripMenuItem miChangeMaster;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripMenuItem miExit;
    private ToolStripMenuItem miTools;
    private ToolStripMenuItem miAudit;
    private ToolStripMenuItem miGenWindow;
    private Panel left;
    private Panel searchPanel;
    private Label lblSearch;
    private TextBox _search;
    private ListView _list;
    private GroupBox right;
    private Label capTitle;
    private TextBox _txtTitle;
    private Label capLogin;
    private TextBox _txtLogin;
    private Label capPassword;
    private TextBox _txtPassword;
    private CheckBox _showPass;
    private Button btnGenerate;
    private Button btnCopy;
    private Label _lblEntropy;
    private Label capUrl;
    private TextBox _txtUrl;
    private Label capNotes;
    private TextBox _txtNotes;
    private Button _btnSave;
    private Button _btnNew;
    private Button btnDelete;
    private StatusStrip _status;
    private ToolStripStatusLabel _statusLabel;
}

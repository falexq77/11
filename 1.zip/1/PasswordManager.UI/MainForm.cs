namespace PasswordManager;
public partial class MainForm : Form
{
    private class Entry
    {
        public string Title = "", Login = "", Password = "", Url = "", Notes = "";
        public DateTime Updated = DateTime.Now;
    }

    private readonly List<Entry> _entries = new();
    private Entry? _editing; 

    public MainForm()
    {
        InitializeComponent();
        LoadDemoData();
        RefreshList();
        SetStatus($"Записей: {_entries.Count}.");
    }
    private void LoadDemoData()
    {
        _entries.Add(new Entry { Title = "GitHub", Login = "student", Password = "demo-pass-1", Url = "https://github.com", Notes = "Учебный аккаунт" });
        _entries.Add(new Entry { Title = "Почта", Login = "student@mail.com", Password = "demo-pass-2", Url = "https://mail.com" });
        _entries.Add(new Entry { Title = "Университет", Login = "s12345", Password = "demo-pass-3", Url = "https://univer.edu", Notes = "Личный кабинет" });
    }

    private void MiLock_Click(object? sender, EventArgs e) => DoLock();
    private void MiChangeMaster_Click(object? sender, EventArgs e)
    {
        using var dlg = new ChangeMasterPasswordDialog();
        dlg.ShowDialog(this);
    }
    private void MiExit_Click(object? sender, EventArgs e) => Close();
    private void MiAudit_Click(object? sender, EventArgs e) =>
        MessageBox.Show(this, "Здесь будет отчёт аудита безопасности.", "Аудит безопасности",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
    private void MiGenWindow_Click(object? sender, EventArgs e) => OpenGenerator(null);

    private void Search_TextChanged(object? sender, EventArgs e) => RefreshList();
    private void List_SelectedIndexChanged(object? sender, EventArgs e) => LoadSelectedIntoForm();

    private void RefreshList()
    {
        string q = _search.Text.Trim();
        _list.BeginUpdate();
        _list.Items.Clear();
        foreach (var en in _entries)
        {
            if (q.Length > 0 &&
                !en.Title.Contains(q, StringComparison.CurrentCultureIgnoreCase) &&
                !en.Login.Contains(q, StringComparison.CurrentCultureIgnoreCase) &&
                !en.Url.Contains(q, StringComparison.CurrentCultureIgnoreCase))
                continue;

            var item = new ListViewItem(en.Title) { Tag = en };
            item.SubItems.Add(en.Login);
            item.SubItems.Add(en.Url);
            item.SubItems.Add(en.Updated.ToString("dd.MM.yyyy HH:mm"));
            _list.Items.Add(item);
        }
        _list.EndUpdate();
    }

    private void LoadSelectedIntoForm()
    {
        if (_list.SelectedItems.Count == 0) return;
        var en = (Entry)_list.SelectedItems[0].Tag!;
        _editing = en;
        _txtTitle.Text = en.Title;
        _txtLogin.Text = en.Login;
        _txtPassword.Text = en.Password;
        _txtUrl.Text = en.Url;
        _txtNotes.Text = en.Notes;
    }

    private void ShowPass_CheckedChanged(object? sender, EventArgs e) =>
        _txtPassword.UseSystemPasswordChar = !_showPass.Checked;

    private void BtnGenerate_Click(object? sender, EventArgs e) => OpenGenerator(_txtPassword);

    private void BtnCopy_Click(object? sender, EventArgs e)
    {
        if (_txtPassword.Text.Length == 0) return;
        Clipboard.SetText(_txtPassword.Text);
        SetStatus("Пароль скопирован в буфер обмена.");
    }

    private void BtnNew_Click(object? sender, EventArgs e) => StartNew();

    private void BtnSave_Click(object? sender, EventArgs e)
    {
        if (_txtTitle.Text.Trim().Length == 0)
        {
            MessageBox.Show(this, "Укажите название записи.", "Проверка формы",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (_txtPassword.Text.Length == 0)
        {
            MessageBox.Show(this, "Пароль не может быть пустым.", "Проверка формы",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        bool isNew = _editing is null;
        var en = _editing ?? new Entry();
        en.Title = _txtTitle.Text.Trim();
        en.Login = _txtLogin.Text.Trim();
        en.Password = _txtPassword.Text;
        en.Url = _txtUrl.Text.Trim();
        en.Notes = _txtNotes.Text;
        en.Updated = DateTime.Now;
        if (isNew) _entries.Add(en);
        _editing = en;

        RefreshList();
        SetStatus(isNew ? $"Запись «{en.Title}» добавлена." : $"Запись «{en.Title}» обновлена.");
    }

    private void BtnDelete_Click(object? sender, EventArgs e)
    {
        if (_editing is null)
        {
            MessageBox.Show(this, "Выберите запись для удаления.", "Удаление",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (MessageBox.Show(this, $"Удалить запись «{_editing.Title}» безвозвратно?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            return;

        _entries.Remove(_editing);
        StartNew();
        RefreshList();
        SetStatus("Запись удалена.");
    }

    private void StartNew()
    {
        _editing = null;
        _list.SelectedItems.Clear();
        foreach (var c in new Control[] { _txtTitle, _txtLogin, _txtPassword, _txtUrl, _txtNotes })
            c.Text = "";
        _txtTitle.Focus();
        SetStatus("Новая запись: заполните форму и нажмите «Сохранить».");
    }

    private void DoLock()
    {
        StartNew();
        using var login = new LoginForm();
        if (login.ShowDialog(this) != DialogResult.OK)
        {
            Close();
            return;
        }
        SetStatus("Хранилище разблокировано.");
    }

    private void OpenGenerator(TextBox? fillTarget)
    {
        using var dlg = new GeneratorForm(fillTarget);
        dlg.ShowDialog(this);
    }

    private void SetStatus(string text, Color? color = null)
    {
        _statusLabel.Text = text;
        _statusLabel.ForeColor = color ?? Color.Empty;
    }
}

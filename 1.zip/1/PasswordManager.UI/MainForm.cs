namespace PasswordManager;
public partial class MainForm : Form
{
    private List<VaultEntry> _entries = new();
    private VaultEntry? _editing;

    public MainForm()
    {
        InitializeComponent();
        LoadFromDatabase();
    }
    private void LoadFromDatabase()
    {
        try
        {
            _entries = Database.GetEntries(Session.UserId, Session.Key);
        }
        catch (System.Security.Cryptography.CryptographicException)
        {
            _entries = new();
            MessageBox.Show(this, "Данные хранилища повреждены или изменены: проверка целостности не пройдена.",
                "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        RefreshList();
        Text = $"Менеджер паролей — {Session.Username}";
        SetStatus($"Записей: {_entries.Count}.");
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        Session.End();
        base.OnFormClosed(e);
    }

    private void MiLock_Click(object? sender, EventArgs e) => DoLock();
    private void MiChangeMaster_Click(object? sender, EventArgs e)
    {
        using var dlg = new ChangeMasterPasswordDialog();
        dlg.ShowDialog(this);
    }
    private void MiExit_Click(object? sender, EventArgs e) => Close();
    private void MiAudit_Click(object? sender, EventArgs e) =>
        MessageBox.Show(this, "Здесь будет отчёт аудита безопасности.", "Аудит безопасности",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
    private void MiGenWindow_Click(object? sender, EventArgs e) => OpenGenerator(null);

    private void Search_TextChanged(object? sender, EventArgs e) => RefreshList();
    private void List_SelectedIndexChanged(object? sender, EventArgs e) => LoadSelectedIntoForm();

    private void RefreshList()
    {
        string q = _search.Text.Trim();
        _list.BeginUpdate();
        _list.Items.Clear();
        foreach (var en in _entries)
        {
            if (q.Length > 0 &&
                !en.Title.Contains(q, StringComparison.CurrentCultureIgnoreCase) &&
                !en.Login.Contains(q, StringComparison.CurrentCultureIgnoreCase) &&
                !en.Url.Contains(q, StringComparison.CurrentCultureIgnoreCase))
                continue;

            var item = new ListViewItem(en.Title) { Tag = en };
            item.SubItems.Add(en.Login);
            item.SubItems.Add(en.Url);
            item.SubItems.Add(en.Updated.ToString("dd.MM.yyyy HH:mm"));
            _list.Items.Add(item);
        }
        _list.EndUpdate();
    }

    private void LoadSelectedIntoForm()
    {
        if (_list.SelectedItems.Count == 0) return;
        var en = (VaultEntry)_list.SelectedItems[0].Tag!;
        _editing = en;
        _txtTitle.Text = en.Title;
        _txtLogin.Text = en.Login;
        _txtPassword.Text = en.Password;
        _txtUrl.Text = en.Url;
        _txtNotes.Text = en.Notes;
    }

    private void ShowPass_CheckedChanged(object? sender, EventArgs e) =>
        _txtPassword.UseSystemPasswordChar = !_showPass.Checked;

    private void BtnGenerate_Click(object? sender, EventArgs e) => OpenGenerator(_txtPassword);

    private void BtnCopy_Click(object? sender, EventArgs e)
    {
        if (_txtPassword.Text.Length == 0) return;
        Clipboard.SetText(_txtPassword.Text);
        SetStatus("Пароль скопирован в буфер обмена.");
    }

    private void BtnNew_Click(object? sender, EventArgs e) => StartNew();

    private void BtnSave_Click(object? sender, EventArgs e)
    {
        if (_txtTitle.Text.Trim().Length == 0)
        {
            MessageBox.Show(this, "Укажите название записи.", "Проверка формы",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (_txtPassword.Text.Length == 0)
        {
            MessageBox.Show(this, "Пароль не может быть пустым.", "Проверка формы",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        bool isNew = _editing is null;
        var en = _editing ?? new VaultEntry();
        en.Title = _txtTitle.Text.Trim();
        en.Login = _txtLogin.Text.Trim();
        en.Password = _txtPassword.Text;
        en.Url = _txtUrl.Text.Trim();
        en.Notes = _txtNotes.Text;
        en.Updated = DateTime.Now;
        Database.SaveEntry(Session.UserId, Session.Key, en);
        if (isNew) _entries.Add(en);
        _editing = en;

        RefreshList();
        SetStatus(isNew ? $"Запись «{en.Title}» добавлена." : $"Запись «{en.Title}» обновлена.");
    }

    private void BtnDelete_Click(object? sender, EventArgs e)
    {
        if (_editing is null)
        {
            MessageBox.Show(this, "Выберите запись для удаления.", "Удаление",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (MessageBox.Show(this, $"Удалить запись «{_editing.Title}» безвозвратно?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            return;

        Database.DeleteEntry(Session.UserId, _editing.Id);
        _entries.Remove(_editing);
        StartNew();
        RefreshList();
        SetStatus("Запись удалена.");
    }

    private void StartNew()
    {
        _editing = null;
        _list.SelectedItems.Clear();
        foreach (var c in new Control[] { _txtTitle, _txtLogin, _txtPassword, _txtUrl, _txtNotes })
            c.Text = "";
        _txtTitle.Focus();
        SetStatus("Новая запись: заполните форму и нажмите «Сохранить».");
    }

    private void DoLock()
    {
        StartNew();
        _entries.Clear();
        RefreshList();
        Session.End();
        using var login = new LoginForm();
        if (login.ShowDialog(this) != DialogResult.OK)
        {
            Close();
            return;
        }
        LoadFromDatabase();
        SetStatus("Хранилище разблокировано.");
    }

    private void OpenGenerator(TextBox? fillTarget)
    {
        using var dlg = new GeneratorForm(fillTarget);
        dlg.ShowDialog(this);
    }

    private void SetStatus(string text, Color? color = null)
    {
        _statusLabel.Text = text;
        _statusLabel.ForeColor = color ?? Color.Empty;
    }
}

using System.Security.Cryptography;

namespace PasswordManager;

internal static class PasswordGenerator
{
    public const string Upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public const string Lower = "abcdefghijklmnopqrstuvwxyz";
    public const string Digits = "0123456789";
    public const string Symbols = "!@#$%^&*()-_=+[]{};:,.?";

    public static string Generate(int length, bool upper = true, bool lower = true, bool digits = true, bool symbols = true)
    {
        var groups = new List<string>();
        if (upper) groups.Add(Upper);
        if (lower) groups.Add(Lower);
        if (digits) groups.Add(Digits);
        if (symbols) groups.Add(Symbols);

        if (groups.Count == 0)
            throw new ArgumentException("Выберите хотя бы один набор символов.");
        if (length < groups.Count)
            throw new ArgumentException($"Длина должна быть не меньше {groups.Count}.");

        string all = string.Concat(groups);
        var chars = new char[length];

        for (int i = 0; i < length; i++)
        {
            string source = i < groups.Count ? groups[i] : all;
            chars[i] = source[RandomNumberGenerator.GetInt32(source.Length)];
        }

        for (int i = length - 1; i > 0; i--)
        {
            int j = RandomNumberGenerator.GetInt32(i + 1);
            (chars[i], chars[j]) = (chars[j], chars[i]);
        }

        return new string(chars);
    }

    public static double Entropy(string password)
    {
        int pool = 0;
        if (password.Any(Upper.Contains)) pool += Upper.Length;
        if (password.Any(Lower.Contains)) pool += Lower.Length;
        if (password.Any(char.IsDigit)) pool += Digits.Length;
        if (password.Any(ch => !char.IsLetterOrDigit(ch))) pool += Symbols.Length;
        return pool == 0 ? 0 : password.Length * Math.Log2(pool);
    }

    public static string StrengthText(string password)
    {
        double bits = Entropy(password);
        string level = bits switch
        {
            < 40 => "слабый",
            < 60 => "средний",
            < 80 => "надёжный",
            _ => "очень надёжный"
        };
        return $"{bits:0} бит — {level}";
    }

    public static Color StrengthColor(string password) => Entropy(password) switch
    {
        < 40 => Color.Firebrick,
        < 60 => Color.DarkOrange,
        _ => Color.ForestGreen
    };
}

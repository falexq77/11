using System.Security.Cryptography;
using System.Text;

namespace PasswordManager;

internal static class PasswordHasher
{
    private const int SaltSize = 16;
    private const int HashSize = 32;
    private const int Iterations = 600_000;
    private static readonly HashAlgorithmName Algorithm = HashAlgorithmName.SHA256;

    public static string Hash(string password)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(SaltSize);
        byte[] hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, Algorithm, HashSize);
        return $"{Iterations}.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
    }

    public static bool Verify(string password, string stored)
    {
        var parts = stored.Split('.');
        if (parts.Length != 3 || !int.TryParse(parts[0], out int iterations))
            return false;

        byte[] salt = Convert.FromBase64String(parts[1]);
        byte[] expected = Convert.FromBase64String(parts[2]);
        byte[] actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, iterations, Algorithm, expected.Length);
        return CryptographicOperations.FixedTimeEquals(actual, expected);
    }

    public static byte[] NewKeySalt() => RandomNumberGenerator.GetBytes(SaltSize);

    public static int IterationsOf(string stored) =>
        int.TryParse(stored.Split('.')[0], out int iterations) ? iterations : Iterations;

    public static byte[] DeriveKey(string password, byte[] keySalt, int iterations = Iterations) =>
        Rfc2898DeriveBytes.Pbkdf2(password, keySalt, iterations, Algorithm, 32);

    public static string Encrypt(byte[] key, string plain)
    {
        byte[] data = Encoding.UTF8.GetBytes(plain);
        byte[] nonce = RandomNumberGenerator.GetBytes(AesGcm.NonceByteSizes.MaxSize);
        byte[] tag = new byte[AesGcm.TagByteSizes.MaxSize];
        byte[] cipher = new byte[data.Length];
        using (var aes = new AesGcm(key, tag.Length))
            aes.Encrypt(nonce, data, cipher, tag);
        return Convert.ToBase64String([.. nonce, .. tag, .. cipher]);
    }

    public static string Decrypt(byte[] key, string encoded)
    {
        byte[] all = Convert.FromBase64String(encoded);
        int n = AesGcm.NonceByteSizes.MaxSize, t = AesGcm.TagByteSizes.MaxSize;
        byte[] plain = new byte[all.Length - n - t];
        using (var aes = new AesGcm(key, t))
            aes.Decrypt(all.AsSpan(0, n), all.AsSpan(n + t), all.AsSpan(n, t), plain);
        return Encoding.UTF8.GetString(plain);
    }
}

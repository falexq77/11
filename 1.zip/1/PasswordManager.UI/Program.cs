namespace PasswordManager;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Database.Init();
        using (var login = new LoginForm())
        {
            if (login.ShowDialog() != DialogResult.OK)
                return; 
        }
        Application.Run(new MainForm());
    }
}

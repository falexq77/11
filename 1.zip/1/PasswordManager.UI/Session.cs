using System.Security.Cryptography;

namespace PasswordManager;

internal static class Session
{
    public static long UserId { get; private set; }
    public static string Username { get; private set; } = "";
    public static byte[] Key { get; private set; } = Array.Empty<byte>();

    public static void Start(long userId, string username, byte[] key)
    {
        End();
        UserId = userId;
        Username = username;
        Key = key;
    }

    public static void End()
    {
        CryptographicOperations.ZeroMemory(Key);
        UserId = 0;
        Username = "";
        Key = Array.Empty<byte>();
    }
}

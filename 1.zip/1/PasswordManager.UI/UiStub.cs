namespace PasswordManager;
internal static class UiStub
{
    public static string PlaceholderPassword(int length)
    {
        const string pattern = "1";
        var chars = new char[length];
        for (int i = 0; i < length; i++) chars[i] = pattern[i % pattern.Length];
        return new string(chars);
    }
}

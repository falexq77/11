 namespace PasswordManager;

public class VaultEntry
{
    public long Id;
    public string Title = "", Login = "", Password = "", Url = "", Notes = "";
    public DateTime Updated = DateTime.Now;
}

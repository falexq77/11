using System;
using System.Data;
using System.Windows.Forms;

namespace TurAgency
{
    public partial class ClientForm : Form
    {
        // код клиента, 0 - значит новый клиент
        int clientId;

        public ClientForm(int id)
        {
            InitializeComponent();
            clientId = id;
            dtpBirth.MaxDate = DateTime.Today;

            if (clientId == 0)
            {
                Text = "Новый клиент";
                dtpBirth.Value = new DateTime(1990, 1, 1);
            }
            else
            {
                Text = "Изменение данных клиента";
                LoadClient();
            }
        }

        // загрузка данных клиента в поля формы
        private void LoadClient()
        {
            DataTable dt = Db.GetTable("SELECT * FROM Клиенты WHERE Код = ?", Db.Par("@id", clientId));
            if (dt.Rows.Count == 0) return;

            DataRow r = dt.Rows[0];
            txtLastName.Text = r["Фамилия"].ToString();
            txtFirstName.Text = r["Имя"].ToString();
            txtMiddleName.Text = r["Отчество"].ToString();
            txtPhone.Text = r["Телефон"].ToString();
            txtPassport.Text = r["Паспорт"].ToString();
            if (r["ДатаРождения"] != DBNull.Value)
                dtpBirth.Value = Convert.ToDateTime(r["ДатаРождения"]);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // проверка обязательных полей
            if (txtLastName.Text.Trim() == "" || txtFirstName.Text.Trim() == "" || txtPhone.Text.Trim() == "")
            {
                MessageBox.Show("Заполните фамилию, имя и телефон", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // в телефоне должно быть не меньше 10 цифр
            int digits = 0;
            foreach (char c in txtPhone.Text)
            {
                if (char.IsDigit(c)) digits++;
            }
            if (digits < 10)
            {
                MessageBox.Show("Телефон введён неправильно", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (clientId == 0)
                {
                    Db.Execute("INSERT INTO Клиенты (Фамилия, Имя, Отчество, Телефон, Паспорт, ДатаРождения) VALUES (?, ?, ?, ?, ?, ?)",
                        Db.Par("@f", txtLastName.Text.Trim()),
                        Db.Par("@i", txtFirstName.Text.Trim()),
                        Db.Par("@o", txtMiddleName.Text.Trim()),
                        Db.Par("@tel", txtPhone.Text.Trim()),
                        Db.Par("@pas", txtPassport.Text.Trim()),
                        Db.Par("@d", dtpBirth.Value.Date));
                }
                else
                {
                    Db.Execute("UPDATE Клиенты SET Фамилия = ?, Имя = ?, Отчество = ?, Телефон = ?, Паспорт = ?, ДатаРождения = ? WHERE Код = ?",
                        Db.Par("@f", txtLastName.Text.Trim()),
                        Db.Par("@i", txtFirstName.Text.Trim()),
                        Db.Par("@o", txtMiddleName.Text.Trim()),
                        Db.Par("@tel", txtPhone.Text.Trim()),
                        Db.Par("@pas", txtPassport.Text.Trim()),
                        Db.Par("@d", dtpBirth.Value.Date),
                        Db.Par("@id", clientId));
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

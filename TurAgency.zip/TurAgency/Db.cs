using System;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;

namespace TurAgency
{
    // Класс для работы с базой данных Access
    static class Db
    {
        // файл базы данных лежит в папке с программой
        public static string DbPath = Path.Combine(Application.StartupPath, "TurAgency.mdb");

        static string ConnString
        {
            get { return "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + DbPath; }
        }

        // данные пользователя, который вошёл в программу
        public static int UserId = 0;
        public static string UserLogin = "";
        public static string UserName = "";
        public static string UserRole = "";

        // выполняет запрос SELECT и возвращает таблицу с результатом
        public static DataTable GetTable(string sql, params OleDbParameter[] pars)
        {
            DataTable dt = new DataTable();
            using (OleDbConnection con = new OleDbConnection(ConnString))
            {
                OleDbCommand cmd = new OleDbCommand(sql, con);
                cmd.Parameters.AddRange(pars);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        // выполняет INSERT, UPDATE или DELETE, возвращает количество измененных строк
        public static int Execute(string sql, params OleDbParameter[] pars)
        {
            using (OleDbConnection con = new OleDbConnection(ConnString))
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand(sql, con);
                cmd.Parameters.AddRange(pars);
                return cmd.ExecuteNonQuery();
            }
        }

        // возвращает одно значение (например COUNT)
        public static object GetValue(string sql, params OleDbParameter[] pars)
        {
            using (OleDbConnection con = new OleDbConnection(ConnString))
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand(sql, con);
                cmd.Parameters.AddRange(pars);
                return cmd.ExecuteScalar();
            }
        }

        // создает параметр для запроса
        // в OleDb параметры подставляются по порядку знаков ?, а имя нужно только для удобства
        public static OleDbParameter Par(string name, object value)
        {
            if (value == null || (value is string && (string)value == ""))
                value = DBNull.Value;
            OleDbParameter p = new OleDbParameter(name, value);
            if (value is DateTime)
                p.OleDbType = OleDbType.Date;
            return p;
        }

        public static bool IsAdmin()
        {
            return UserRole == "Администратор";
        }
    }
}

using System;
using System.Data;
using System.Windows.Forms;

namespace TurAgency
{
    public partial class LoginForm : Form
    {
        // счетчик неудачных попыток входа
        int tries = 0;

        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text;

            if (login == "" || password == "")
            {
                MessageBox.Show("Введите логин и пароль", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataTable dt;
            try
            {
                // ищем пользователя по логину
                dt = Db.GetTable("SELECT Код, Логин, Пароль, ФИО, Роль FROM Пользователи WHERE Логин = ?",
                    Db.Par("@login", login));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения к базе данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // пароль сравниваем в программе, потому что Access сравнивает строки без учета регистра
            if (dt.Rows.Count == 1 && dt.Rows[0]["Пароль"].ToString() == password)
            {
                Db.UserId = Convert.ToInt32(dt.Rows[0]["Код"]);
                Db.UserLogin = dt.Rows[0]["Логин"].ToString();
                Db.UserName = dt.Rows[0]["ФИО"].ToString();
                Db.UserRole = dt.Rows[0]["Роль"].ToString();
                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                tries++;
                txtPassword.Clear();
                if (tries >= 3)
                {
                    MessageBox.Show("Превышено количество попыток входа. Программа будет закрыта.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    DialogResult = DialogResult.Cancel;
                    Close();
                    return;
                }
                MessageBox.Show("Неверный логин или пароль. Осталось попыток: " + (3 - tries), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegisterForm f = new RegisterForm();
            if (f.ShowDialog() == DialogResult.OK)
            {
                // подставляем логин нового пользователя
                txtLogin.Text = f.NewLogin;
                txtPassword.Clear();
                txtPassword.Focus();
            }
        }

        private void chkShow_CheckedChanged(object sender, EventArgs e)
        {
            // показать или скрыть пароль
            if (chkShow.Checked)
                txtPassword.PasswordChar = '\0';
            else
                txtPassword.PasswordChar = '*';
        }
    }
}

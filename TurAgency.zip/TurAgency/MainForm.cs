using System;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace TurAgency
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            lblUser.Text = "Пользователь: " + Db.UserName + " (" + Db.UserRole + ")";
            try
            {
                LoadClients();
                LoadTours();
                LoadVouchers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowCount();
        }

        // ================= Клиенты =================

        private void LoadClients()
        {
            string sql = "SELECT Код, Фамилия, Имя, Отчество, Телефон, Паспорт, ДатаРождения AS [Дата рождения] " +
                         "FROM Клиенты WHERE Фамилия LIKE ? ORDER BY Фамилия, Имя";
            dgvClients.DataSource = Db.GetTable(sql, Db.Par("@f", txtSearchClients.Text.Trim() + "%"));
        }

        private void txtSearchClients_TextChanged(object sender, EventArgs e)
        {
            LoadClients();
            ShowCount();
        }

        private void btnAddClient_Click(object sender, EventArgs e)
        {
            ClientForm f = new ClientForm(0);
            if (f.ShowDialog() == DialogResult.OK)
            {
                LoadClients();
                ShowCount();
            }
        }

        private void btnEditClient_Click(object sender, EventArgs e)
        {
            int id = GetSelectedId(dgvClients);
            if (id == 0) return;
            ClientForm f = new ClientForm(id);
            if (f.ShowDialog() == DialogResult.OK)
            {
                LoadClients();
                LoadVouchers();
            }
        }

        private void btnDeleteClient_Click(object sender, EventArgs e)
        {
            int id = GetSelectedId(dgvClients);
            if (id == 0) return;
            if (!CheckAdmin()) return;

            // нельзя удалить клиента, если на него оформлены путевки
            int count = Convert.ToInt32(Db.GetValue("SELECT COUNT(*) FROM Путевки WHERE КодКлиента = ?", Db.Par("@id", id)));
            if (count > 0)
            {
                MessageBox.Show("Нельзя удалить клиента, на него оформлено путёвок: " + count, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Удалить выбранного клиента?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Db.Execute("DELETE FROM Клиенты WHERE Код = ?", Db.Par("@id", id));
                LoadClients();
                ShowCount();
            }
        }

        // ================= Туры =================

        private void LoadTours()
        {
            string sql = "SELECT Код, Название, Страна, Город, Отель, Дней, Цена, Описание " +
                         "FROM Туры WHERE Название LIKE ? OR Страна LIKE ? ORDER BY Страна, Название";
            string s = "%" + txtSearchTours.Text.Trim() + "%";
            dgvTours.DataSource = Db.GetTable(sql, Db.Par("@n", s), Db.Par("@c", s));
        }

        private void txtSearchTours_TextChanged(object sender, EventArgs e)
        {
            LoadTours();
            ShowCount();
        }

        private void btnAddTour_Click(object sender, EventArgs e)
        {
            TourForm f = new TourForm(0);
            if (f.ShowDialog() == DialogResult.OK)
            {
                LoadTours();
                ShowCount();
            }
        }

        private void btnEditTour_Click(object sender, EventArgs e)
        {
            int id = GetSelectedId(dgvTours);
            if (id == 0) return;
            TourForm f = new TourForm(id);
            if (f.ShowDialog() == DialogResult.OK)
            {
                LoadTours();
                LoadVouchers();
            }
        }

        private void btnDeleteTour_Click(object sender, EventArgs e)
        {
            int id = GetSelectedId(dgvTours);
            if (id == 0) return;
            if (!CheckAdmin()) return;

            int count = Convert.ToInt32(Db.GetValue("SELECT COUNT(*) FROM Путевки WHERE КодТура = ?", Db.Par("@id", id)));
            if (count > 0)
            {
                MessageBox.Show("Нельзя удалить тур, по нему оформлено путёвок: " + count, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Удалить выбранный тур?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Db.Execute("DELETE FROM Туры WHERE Код = ?", Db.Par("@id", id));
                LoadTours();
                ShowCount();
            }
        }

        // ================= Путевки =================

        private void LoadVouchers()
        {
            string sql = "SELECT p.Код, k.Фамилия & ' ' & k.Имя AS Клиент, t.Название AS Тур, t.Страна, " +
                         "p.ДатаОформления AS Оформлена, p.ДатаВыезда AS Выезд, p.Человек, p.Сумма, p.Статус " +
                         "FROM (Путевки AS p INNER JOIN Клиенты AS k ON p.КодКлиента = k.Код) " +
                         "INNER JOIN Туры AS t ON p.КодТура = t.Код " +
                         "WHERE k.Фамилия LIKE ? ORDER BY p.ДатаОформления DESC";
            dgvVouchers.DataSource = Db.GetTable(sql, Db.Par("@f", txtSearchVouchers.Text.Trim() + "%"));
        }

        private void txtSearchVouchers_TextChanged(object sender, EventArgs e)
        {
            LoadVouchers();
            ShowCount();
        }

        private void btnAddVoucher_Click(object sender, EventArgs e)
        {
            VoucherForm f = new VoucherForm(0);
            if (f.ShowDialog() == DialogResult.OK)
            {
                LoadVouchers();
                ShowCount();
            }
        }

        private void btnEditVoucher_Click(object sender, EventArgs e)
        {
            int id = GetSelectedId(dgvVouchers);
            if (id == 0) return;
            VoucherForm f = new VoucherForm(id);
            if (f.ShowDialog() == DialogResult.OK)
                LoadVouchers();
        }

        private void btnDeleteVoucher_Click(object sender, EventArgs e)
        {
            int id = GetSelectedId(dgvVouchers);
            if (id == 0) return;
            if (!CheckAdmin()) return;

            if (MessageBox.Show("Удалить выбранную путёвку?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Db.Execute("DELETE FROM Путевки WHERE Код = ?", Db.Par("@id", id));
                LoadVouchers();
                ShowCount();
            }
        }

        // ================= Общие методы =================

        // возвращает код выбранной строки, 0 - если ничего не выбрано
        private int GetSelectedId(DataGridView dgv)
        {
            if (dgv.CurrentRow == null)
            {
                MessageBox.Show("Сначала выберите запись в таблице", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return 0;
            }
            return Convert.ToInt32(dgv.CurrentRow.Cells["Код"].Value);
        }

        // удалять записи может только администратор
        private bool CheckAdmin()
        {
            if (!Db.IsAdmin())
            {
                MessageBox.Show("Удалять записи может только администратор", "Нет прав", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        // количество записей на открытой вкладке
        private void ShowCount()
        {
            // считаем строки в таблице данных, так как у скрытой вкладки строки в сетке еще не созданы
            if (tabControl1.SelectedIndex == 0)
                lblCount.Text = "Клиентов: " + ((DataTable)dgvClients.DataSource).Rows.Count;
            else if (tabControl1.SelectedIndex == 1)
                lblCount.Text = "Туров: " + ((DataTable)dgvTours.DataSource).Rows.Count;
            else
                lblCount.Text = "Путёвок: " + ((DataTable)dgvVouchers.DataSource).Rows.Count;
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowCount();
        }

        // двойной щелчок по строке открывает ее на изменение
        private void dgvClients_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) btnEditClient_Click(sender, e);
        }

        private void dgvTours_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) btnEditTour_Click(sender, e);
        }

        private void dgvVouchers_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) btnEditVoucher_Click(sender, e);
        }

        // настройка столбцов делается после привязки данных,
        // иначе у таблиц на скрытых вкладках столбцов еще нет
        private void dgvClients_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (dgvClients.Columns.Count == 0) return;
            dgvClients.Columns["Код"].FillWeight = 40;
            dgvClients.Columns["Дата рождения"].DefaultCellStyle.Format = "dd.MM.yyyy";
        }

        private void dgvTours_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (dgvTours.Columns.Count == 0) return;
            dgvTours.Columns["Код"].FillWeight = 40;
            dgvTours.Columns["Дней"].FillWeight = 45;
            dgvTours.Columns["Цена"].DefaultCellStyle.Format = "N2";
        }

        private void dgvVouchers_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (dgvVouchers.Columns.Count == 0) return;
            dgvVouchers.Columns["Код"].FillWeight = 40;
            dgvVouchers.Columns["Человек"].FillWeight = 55;
            dgvVouchers.Columns["Оформлена"].DefaultCellStyle.Format = "dd.MM.yyyy";
            dgvVouchers.Columns["Выезд"].DefaultCellStyle.Format = "dd.MM.yyyy";
            dgvVouchers.Columns["Сумма"].DefaultCellStyle.Format = "N2";
        }

        // ================= Меню =================

        private void menuReport_Click(object sender, EventArgs e)
        {
            ReportForm f = new ReportForm();
            f.ShowDialog();
        }

        private void menuBackup_Click(object sender, EventArgs e)
        {
            // резервная копия - просто копируем файл базы
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "База данных Access (*.mdb)|*.mdb";
            sfd.FileName = "TurAgency_" + DateTime.Now.ToString("yyyy-MM-dd") + ".mdb";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    File.Copy(Db.DbPath, sfd.FileName, true);
                    MessageBox.Show("Резервная копия сохранена", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Не удалось сохранить копию: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void menuAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Программа для автоматизации деятельности туристического агентства\n\n" +
                            "Курсовая работа по дисциплине\n«Основы алгоритмизации и программирования»\n\nСтаврополь, 2026",
                            "О программе", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

using System;
using System.IO;
using System.Windows.Forms;

namespace TurAgency
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // проверяем, что файл базы данных лежит рядом с программой
            if (!File.Exists(Db.DbPath))
            {
                MessageBox.Show("Не найден файл базы данных:\n" + Db.DbPath, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // сначала окно входа, если вход успешный - открываем главное окно
            LoginForm login = new LoginForm();
            if (login.ShowDialog() == DialogResult.OK)
            {
                Application.Run(new MainForm());
            }
        }
    }
}

using System;
using System.Windows.Forms;

namespace TurAgency
{
    public partial class RegisterForm : Form
    {
        // логин нового пользователя, чтобы подставить его в окно входа
        public string NewLogin = "";

        public RegisterForm()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string fio = txtFio.Text.Trim();
            string login = txtLogin.Text.Trim();
            string pass1 = txtPass1.Text;
            string pass2 = txtPass2.Text;

            // проверка заполнения
            if (fio == "" || login == "" || pass1 == "" || pass2 == "")
            {
                MessageBox.Show("Заполните все поля", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (login.Contains(" "))
            {
                MessageBox.Show("Логин не должен содержать пробелы", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (pass1.Length < 6)
            {
                MessageBox.Show("Пароль должен быть не короче 6 символов", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (pass1 != pass2)
            {
                MessageBox.Show("Пароли не совпадают", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // логин должен быть уникальным
                int count = Convert.ToInt32(Db.GetValue("SELECT COUNT(*) FROM Пользователи WHERE Логин = ?", Db.Par("@login", login)));
                if (count > 0)
                {
                    MessageBox.Show("Пользователь с таким логином уже существует", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // новый пользователь всегда получает роль "Менеджер"
                Db.Execute("INSERT INTO Пользователи (Логин, Пароль, Роль, ФИО) VALUES (?, ?, ?, ?)",
                    Db.Par("@login", login),
                    Db.Par("@pass", pass1),
                    Db.Par("@role", "Менеджер"),
                    Db.Par("@fio", fio));

                MessageBox.Show("Пользователь зарегистрирован. Теперь можно войти в программу.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
                NewLogin = login;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка регистрации: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

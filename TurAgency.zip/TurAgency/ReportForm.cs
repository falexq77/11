using System;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace TurAgency
{
    public partial class ReportForm : Form
    {
        DataTable report = null;

        public ReportForm()
        {
            InitializeComponent();
            // по умолчанию отчет за текущий месяц
            dtpFrom.Value = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            dtpTo.Value = DateTime.Today;
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            if (dtpFrom.Value.Date > dtpTo.Value.Date)
            {
                MessageBox.Show("Дата начала периода больше даты окончания", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // отмененные путевки в продажи не входят
            string sql = "SELECT p.ДатаОформления AS Дата, k.Фамилия & ' ' & k.Имя AS Клиент, t.Название AS Тур, t.Страна, " +
                         "p.Человек, p.Сумма, p.Статус " +
                         "FROM (Путевки AS p INNER JOIN Клиенты AS k ON p.КодКлиента = k.Код) " +
                         "INNER JOIN Туры AS t ON p.КодТура = t.Код " +
                         "WHERE p.ДатаОформления BETWEEN ? AND ? AND p.Статус <> 'Отменена' " +
                         "ORDER BY p.ДатаОформления";
            report = Db.GetTable(sql, Db.Par("@d1", dtpFrom.Value.Date), Db.Par("@d2", dtpTo.Value.Date));
            dataGridView1.DataSource = report;
            dataGridView1.Columns["Дата"].DefaultCellStyle.Format = "dd.MM.yyyy";
            dataGridView1.Columns["Сумма"].DefaultCellStyle.Format = "N2";

            // считаем итоги
            int people = 0;
            decimal total = 0;
            foreach (DataRow r in report.Rows)
            {
                people += Convert.ToInt32(r["Человек"]);
                total += Convert.ToDecimal(r["Сумма"]);
            }
            lblTotal.Text = "Продано путёвок: " + report.Rows.Count + ",  туристов: " + people + ",  на сумму: " + total.ToString("N2") + " руб.";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (report == null || report.Rows.Count == 0)
            {
                MessageBox.Show("Сначала сформируйте отчёт", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Текстовый файл (*.txt)|*.txt";
            sfd.FileName = "Отчет_" + dtpFrom.Value.ToString("dd.MM.yyyy") + "-" + dtpTo.Value.ToString("dd.MM.yyyy") + ".txt";
            if (sfd.ShowDialog() != DialogResult.OK)
                return;

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Отчёт по продажам путёвок турагентства «Горизонт»");
            sb.AppendLine("Период: " + dtpFrom.Value.ToString("dd.MM.yyyy") + " - " + dtpTo.Value.ToString("dd.MM.yyyy"));
            sb.AppendLine("Сформировал: " + Db.UserName);
            sb.AppendLine();
            foreach (DataRow r in report.Rows)
            {
                sb.AppendLine(Convert.ToDateTime(r["Дата"]).ToString("dd.MM.yyyy") + "\t" + r["Клиент"] + "\t" + r["Тур"] + "\t" +
                              r["Страна"] + "\t" + r["Человек"] + " чел.\t" + Convert.ToDecimal(r["Сумма"]).ToString("N2") + " руб.\t" + r["Статус"]);
            }
            sb.AppendLine();
            sb.AppendLine(lblTotal.Text);

            try
            {
                File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                MessageBox.Show("Отчёт сохранён", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить файл: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

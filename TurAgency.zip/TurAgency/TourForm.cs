using System;
using System.Data;
using System.Windows.Forms;

namespace TurAgency
{
    public partial class TourForm : Form
    {
        // код тура, 0 - новый тур
        int tourId;

        public TourForm(int id)
        {
            InitializeComponent();
            tourId = id;

            if (tourId == 0)
            {
                Text = "Новый тур";
            }
            else
            {
                Text = "Изменение тура";
                LoadTour();
            }
        }

        private void LoadTour()
        {
            DataTable dt = Db.GetTable("SELECT * FROM Туры WHERE Код = ?", Db.Par("@id", tourId));
            if (dt.Rows.Count == 0) return;

            DataRow r = dt.Rows[0];
            txtName.Text = r["Название"].ToString();
            txtCountry.Text = r["Страна"].ToString();
            txtCity.Text = r["Город"].ToString();
            txtHotel.Text = r["Отель"].ToString();
            numDays.Value = Convert.ToInt32(r["Дней"]);
            numPrice.Value = Convert.ToDecimal(r["Цена"]);
            txtDescription.Text = r["Описание"].ToString();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Trim() == "" || txtCountry.Text.Trim() == "")
            {
                MessageBox.Show("Заполните название тура и страну", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (numPrice.Value <= 0)
            {
                MessageBox.Show("Цена тура должна быть больше нуля", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (tourId == 0)
                {
                    Db.Execute("INSERT INTO Туры (Название, Страна, Город, Отель, Дней, Цена, Описание) VALUES (?, ?, ?, ?, ?, ?, ?)",
                        Db.Par("@n", txtName.Text.Trim()),
                        Db.Par("@s", txtCountry.Text.Trim()),
                        Db.Par("@g", txtCity.Text.Trim()),
                        Db.Par("@o", txtHotel.Text.Trim()),
                        Db.Par("@d", (int)numDays.Value),
                        Db.Par("@c", numPrice.Value),
                        Db.Par("@op", txtDescription.Text.Trim()));
                }
                else
                {
                    Db.Execute("UPDATE Туры SET Название = ?, Страна = ?, Город = ?, Отель = ?, Дней = ?, Цена = ?, Описание = ? WHERE Код = ?",
                        Db.Par("@n", txtName.Text.Trim()),
                        Db.Par("@s", txtCountry.Text.Trim()),
                        Db.Par("@g", txtCity.Text.Trim()),
                        Db.Par("@o", txtHotel.Text.Trim()),
                        Db.Par("@d", (int)numDays.Value),
                        Db.Par("@c", numPrice.Value),
                        Db.Par("@op", txtDescription.Text.Trim()),
                        Db.Par("@id", tourId));
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

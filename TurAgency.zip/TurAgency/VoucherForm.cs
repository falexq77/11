using System;
using System.Data;
using System.Windows.Forms;

namespace TurAgency
{
    public partial class VoucherForm : Form
    {
        // код путевки, 0 - новая путевка
        int voucherId;

        public VoucherForm(int id)
        {
            InitializeComponent();
            voucherId = id;

            // заполняем выпадающие списки из базы
            cmbClient.DisplayMember = "ФИО";
            cmbClient.ValueMember = "Код";
            cmbClient.DataSource = Db.GetTable("SELECT Код, Фамилия & ' ' & Имя & ' ' & Отчество AS ФИО FROM Клиенты ORDER BY Фамилия, Имя");

            cmbTour.DisplayMember = "Название";
            cmbTour.ValueMember = "Код";
            cmbTour.DataSource = Db.GetTable("SELECT Код, Название, Цена FROM Туры ORDER BY Название");

            cmbStatus.Items.Add("Забронирована");
            cmbStatus.Items.Add("Оплачена");
            cmbStatus.Items.Add("Отменена");
            cmbStatus.SelectedIndex = 0;

            if (voucherId == 0)
            {
                Text = "Оформление путёвки";
                dtpStart.Value = DateTime.Today.AddDays(7);
            }
            else
            {
                Text = "Изменение путёвки";
                LoadVoucher();
            }
            CalcSum();
        }

        private void LoadVoucher()
        {
            DataTable dt = Db.GetTable("SELECT * FROM Путевки WHERE Код = ?", Db.Par("@id", voucherId));
            if (dt.Rows.Count == 0) return;

            DataRow r = dt.Rows[0];
            cmbClient.SelectedValue = r["КодКлиента"];
            cmbTour.SelectedValue = r["КодТура"];
            dtpStart.Value = Convert.ToDateTime(r["ДатаВыезда"]);
            numPeople.Value = Convert.ToInt32(r["Человек"]);
            cmbStatus.Text = r["Статус"].ToString();
        }

        // расчет стоимости: цена тура * количество человек,
        // если человек 4 и больше - скидка 5%
        private decimal CalcSum()
        {
            if (cmbTour.SelectedItem == null)
                return 0;

            DataRowView row = (DataRowView)cmbTour.SelectedItem;
            decimal price = Convert.ToDecimal(row["Цена"]);
            int people = (int)numPeople.Value;

            decimal sum = price * people;
            if (people >= 4)
                sum = sum * 0.95m;

            lblPrice.Text = "Цена тура за 1 человека: " + price.ToString("N2") + " руб.";
            lblSum.Text = "Итого к оплате: " + sum.ToString("N2") + " руб.";
            if (people >= 4)
                lblSum.Text += " (со скидкой)";
            return sum;
        }

        private void cmbTour_SelectedIndexChanged(object sender, EventArgs e)
        {
            CalcSum();
        }

        private void numPeople_ValueChanged(object sender, EventArgs e)
        {
            CalcSum();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbClient.SelectedValue == null || cmbTour.SelectedValue == null)
            {
                MessageBox.Show("Выберите клиента и тур", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // для новой путевки дата выезда не может быть в прошлом
            if (voucherId == 0 && dtpStart.Value.Date < DateTime.Today)
            {
                MessageBox.Show("Дата выезда не может быть раньше сегодняшней", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal sum = CalcSum();
            try
            {
                if (voucherId == 0)
                {
                    Db.Execute("INSERT INTO Путевки (КодКлиента, КодТура, ДатаОформления, ДатаВыезда, Человек, Сумма, Статус) VALUES (?, ?, ?, ?, ?, ?, ?)",
                        Db.Par("@k", cmbClient.SelectedValue),
                        Db.Par("@t", cmbTour.SelectedValue),
                        Db.Par("@do", DateTime.Today),
                        Db.Par("@dv", dtpStart.Value.Date),
                        Db.Par("@ch", (int)numPeople.Value),
                        Db.Par("@s", sum),
                        Db.Par("@st", cmbStatus.Text));
                }
                else
                {
                    Db.Execute("UPDATE Путевки SET КодКлиента = ?, КодТура = ?, ДатаВыезда = ?, Человек = ?, Сумма = ?, Статус = ? WHERE Код = ?",
                        Db.Par("@k", cmbClient.SelectedValue),
                        Db.Par("@t", cmbTour.SelectedValue),
                        Db.Par("@dv", dtpStart.Value.Date),
                        Db.Par("@ch", (int)numPeople.Value),
                        Db.Par("@s", sum),
                        Db.Par("@st", cmbStatus.Text),
                        Db.Par("@id", voucherId));
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
